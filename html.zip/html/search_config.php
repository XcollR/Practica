<?php

$config = array(
  'PROJECT_NAME' => "Creació d&#39;un arbre filogenètic.",
  'GENERATE_TREEVIEW' => false,
  'DISABLE_INDEX' => false,
);

$translator = array(
  'search_results_title' => "Resultados de la Búsqueda",
  'search_results' => array(
    0 => "Disculpe, no se encontraron documentos que coincidan con su búsqueda.",
    1 => "Se encontró <b>1</b> documento que coincide con su búsqueda.",
    2 => "Se encontraron <b>\$num</b> documentos que coinciden con su búsqueda. Se muestran los mejores resultados primero.",
  ),
  'search_matches' => "Coincidencias:",
  'search' => "Buscar",
  'split_bar' => "",
  'logo' => "Generado por&#160;\n<a href=\"http://www.doxygen.org/index.html\">\n<img class=\"footer\" src=\"doxygen.png\" alt=\"doxygen\"/></a> 1.8.18 ",
);

?>
