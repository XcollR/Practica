var _cjt__clusters_8hh =
[
    [ "Cjt_clusters", "class_cjt__clusters.html", "class_cjt__clusters" ],
    [ "CJT_CLUSTER_HH", "_cjt__clusters_8hh.html#af283c7c3076dbf48e48e3af57118520f", null ]
];