var class_cluster =
[
    [ "Cluster", "class_cluster.html#a4702942c6848ae6fbb7de215b49797d5", null ],
    [ "Cluster", "class_cluster.html#aaf336dfa4bfb02c0fd71395615636fb4", null ],
    [ "inm_escriure", "class_cluster.html#a1856b0f1ca9243208451c965313af753", null ],
    [ "escriure", "class_cluster.html#aae67c144fc543eace946dc8a651b5b7a", null ],
    [ "cluster", "class_cluster.html#a34b4dbc09bb7d69a7f2fb8ce390d6174", null ]
];