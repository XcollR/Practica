var files_dup =
[
    [ "Cjt_clusters.cc", "_cjt__clusters_8cc.html", null ],
    [ "Cjt_clusters.hh", "_cjt__clusters_8hh.html", [
      [ "Cjt_clusters", "class_cjt__clusters.html", "class_cjt__clusters" ]
    ] ],
    [ "Cjt_especies.cc", "_cjt__especies_8cc.html", null ],
    [ "Cjt_especies.hh", "_cjt__especies_8hh.html", [
      [ "Cjt_especies", "class_cjt__especies.html", "class_cjt__especies" ]
    ] ],
    [ "Cluster.cc", "_cluster_8cc.html", null ],
    [ "Cluster.hh", "_cluster_8hh.html", [
      [ "Cluster", "class_cluster.html", "class_cluster" ]
    ] ],
    [ "Especie.cc", "_especie_8cc.html", null ],
    [ "Especie.hh", "_especie_8hh.html", [
      [ "Especie", "class_especie.html", "class_especie" ]
    ] ],
    [ "program.cc", "program_8cc.html", "program_8cc" ]
];