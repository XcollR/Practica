var searchData=
[
  ['set_5fparametro_46',['set_parametro',['../class_especie.html#a1d513b21daca76fa150dd1d62c590093',1,'Especie']]]
];
