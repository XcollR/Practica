var searchData=
[
  ['tabla_5fdist_5fclust_97',['tabla_dist_clust',['../class_cjt__clusters.html#a8298bacd14980c99c9558c72702174e8',1,'Cjt_clusters']]],
  ['tabla_5fdistancias_98',['tabla_distancias',['../class_cjt__especies.html#a653d6b120928015ad38a5dc30ebeec8e',1,'Cjt_especies']]]
];
