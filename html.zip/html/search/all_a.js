var searchData=
[
  ['obtener_5fgen_44',['obtener_gen',['../class_cjt__especies.html#a57ed04e290bf802050d19ca1956c2663',1,'Cjt_especies']]]
];
