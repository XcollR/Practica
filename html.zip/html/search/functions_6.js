var searchData=
[
  ['kmer_91',['kmer',['../class_especie.html#a2bd896f271d0983f609735df8809cccc',1,'Especie']]]
];
