var searchData=
[
  ['dist_5fclust_16',['dist_clust',['../class_cjt__clusters.html#a85f675adbd2142e12825c9bf84c53521',1,'Cjt_clusters']]],
  ['distancia_17',['distancia',['../class_especie.html#a2037b4bf2d55d8c6ffb90811ad1c4a1b',1,'Especie']]]
];
