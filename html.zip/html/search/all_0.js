var searchData=
[
  ['actual_0',['actual',['../class_cjt__especies.html#a2cd05fceb53ec9604eb4dcb6abea1c4d',1,'Cjt_especies']]],
  ['afegeix_5fespecie_5fclusters_1',['afegeix_especie_clusters',['../class_cjt__clusters.html#aa032b0cd8fc22d549d986739b7e10b31',1,'Cjt_clusters']]],
  ['afegeix_5fespecie_5ftabla_5fdist_2',['afegeix_especie_tabla_dist',['../class_cjt__especies.html#a90a082e134d49bc8cee834b4ff5d0e8b',1,'Cjt_especies']]],
  ['avanza_3',['avanza',['../class_cjt__especies.html#acc3beaf9ea5a96f33296f5cc15b8b5a2',1,'Cjt_especies']]]
];
