var searchData=
[
  ['tabla_5fdistancias_5fcluster_106',['tabla_distancias_cluster',['../class_cjt__clusters.html#aa8d53231821f38f1867001be195d8d63',1,'Cjt_clusters']]],
  ['taula_5fdistancies_107',['taula_distancies',['../class_cjt__especies.html#a11b8753b208b06eac1585faafa8d7bae',1,'Cjt_especies']]]
];
