var searchData=
[
  ['k_5fmeros_37',['k_meros',['../class_especie.html#a0c42a37fe5502ebbe9e91e364c90bd3e',1,'Especie']]],
  ['k_5fnum_38',['k_num',['../class_especie.html#a8cea60787f2ca85fd94a2d96f853f93f',1,'Especie']]],
  ['kmer_39',['kmer',['../class_especie.html#a2bd896f271d0983f609735df8809cccc',1,'Especie']]]
];
