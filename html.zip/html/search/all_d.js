var searchData=
[
  ['tabla_5fdist_5fclust_47',['tabla_dist_clust',['../class_cjt__clusters.html#a8298bacd14980c99c9558c72702174e8',1,'Cjt_clusters']]],
  ['tabla_5fdistancias_48',['tabla_distancias',['../class_cjt__especies.html#a653d6b120928015ad38a5dc30ebeec8e',1,'Cjt_especies']]],
  ['tabla_5fdistancias_5fcluster_49',['tabla_distancias_cluster',['../class_cjt__clusters.html#aa8d53231821f38f1867001be195d8d63',1,'Cjt_clusters']]],
  ['taula_5fdistancies_50',['taula_distancies',['../class_cjt__especies.html#a11b8753b208b06eac1585faafa8d7bae',1,'Cjt_especies']]]
];
