var indexSectionsWithContent =
{
  0: "acdefgiklmopst",
  1: "ce",
  2: "cep",
  3: "acdefiklmost",
  4: "cgikmt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables"
};

