var class_especie =
[
    [ "Especie", "class_especie.html#a272c2488719cc9874b2f174906675b3d", null ],
    [ "Especie", "class_especie.html#a07bc78385f51aff88a16e24575a6756f", null ],
    [ "kmer", "class_especie.html#a2bd896f271d0983f609735df8809cccc", null ],
    [ "consultar_gen", "class_especie.html#a850af2b59a21e2d801c59d76ba5c1a98", null ],
    [ "distancia", "class_especie.html#a2037b4bf2d55d8c6ffb90811ad1c4a1b", null ],
    [ "escriure", "class_especie.html#ae24802ae0746b2560a48eea40f64760e", null ],
    [ "gen", "class_especie.html#ac35bb565f7346cd6317b3a8c849456d1", null ],
    [ "k_meros", "class_especie.html#a0c42a37fe5502ebbe9e91e364c90bd3e", null ]
];