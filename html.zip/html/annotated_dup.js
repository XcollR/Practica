var annotated_dup =
[
    [ "Cjt_clusters", "class_cjt__clusters.html", "class_cjt__clusters" ],
    [ "Cjt_especies", "class_cjt__especies.html", "class_cjt__especies" ],
    [ "Cluster", "class_cluster.html", "class_cluster" ],
    [ "Especie", "class_especie.html", "class_especie" ]
];