var class_cjt__especies =
[
    [ "Cjt_especies", "class_cjt__especies.html#ab297567c73ccd8caefbd8760d90294a1", null ],
    [ "elimina_especie_tabla_dist", "class_cjt__especies.html#aa9f562fc745558783a3634c38df07ad5", null ],
    [ "afegeix_especie_tabla_dist", "class_cjt__especies.html#a90a082e134d49bc8cee834b4ff5d0e8b", null ],
    [ "crea_especie", "class_cjt__especies.html#a6413c062ece1d559a050bac7a6d02fc9", null ],
    [ "elimina_especie", "class_cjt__especies.html#a51059c15bd4c38ff5f21dbb532befa11", null ],
    [ "existeix_especie", "class_cjt__especies.html#a7fa2f303eb4e3065d87174a1c3e71942", null ],
    [ "calcular_distancia", "class_cjt__especies.html#aa4191c64a5008de2272e0e3489aeb778", null ],
    [ "obtener_gen", "class_cjt__especies.html#a57ed04e290bf802050d19ca1956c2663", null ],
    [ "final", "class_cjt__especies.html#a44c59750dd9223ea12f954247fd11504", null ],
    [ "inicio", "class_cjt__especies.html#aedcfb0e423c5c02653c8a5d362cfa784", null ],
    [ "actual", "class_cjt__especies.html#a2cd05fceb53ec9604eb4dcb6abea1c4d", null ],
    [ "avanza", "class_cjt__especies.html#acc3beaf9ea5a96f33296f5cc15b8b5a2", null ],
    [ "lee_cjt_especies", "class_cjt__especies.html#a1f554d3f098484c20372c43b844752db", null ],
    [ "imprime_cjt_especies", "class_cjt__especies.html#aba7f0f935b6e0b8eb38337ad8675fead", null ],
    [ "tabla_distancias", "class_cjt__especies.html#a653d6b120928015ad38a5dc30ebeec8e", null ],
    [ "cjt_especies", "class_cjt__especies.html#a89de09003e9a86f62766d89ed22d599f", null ],
    [ "taula_distancies", "class_cjt__especies.html#a11b8753b208b06eac1585faafa8d7bae", null ],
    [ "it", "class_cjt__especies.html#a52fed7408be24ac0dc3462b24ddb06a0", null ]
];